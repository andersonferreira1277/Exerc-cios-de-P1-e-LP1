# Arquivo para teste do modelo
"""
a = DadosDoAluno("Anderson Ferreira Câmara", "Adeilton", "Marineide")
b = DadosDeNascimento("07/03/1994", "Maceió", "Alagoas")
c = DadosDaTurma("3º ano", "Ensino Médio", "2018")
al = Aluno(a, b, c)

Modelo.replaceModel(al)"""