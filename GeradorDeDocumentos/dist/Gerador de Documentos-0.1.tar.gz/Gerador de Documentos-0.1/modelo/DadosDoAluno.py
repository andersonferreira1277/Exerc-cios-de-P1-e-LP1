# -*- coding: UTF-8 -*-
"""
andersonferreira1277@gmail.com
"""


class DadosDoAluno:

    def __init__(self, nomeAluno, nomeDoPai, nomeDaMae):
        """Nome do aluno, Nome do Pai do Aluno, Nome da mãe do aluno"""
        self.nomeAluno = nomeAluno
        self.nomeDoPai = nomeDoPai
        self.nomeDaMae = nomeDaMae