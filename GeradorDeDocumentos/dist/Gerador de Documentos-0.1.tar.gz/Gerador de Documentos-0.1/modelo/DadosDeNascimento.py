# -*- coding: UTF-8 -*-
"""
andersonferreira1277@gmail.com
"""


class DadosDeNascimento:
    def __init__(self, dataDeNascimento, cidadeDeNascimento, estadoDeNascimento):
        """dataDeNascimento, cidadeDeNascimento, estadoDeNascimento"""
        self.dataDeNascimento = dataDeNascimento
        self.cidadeDeNascimento = cidadeDeNascimento
        self.estadoDeNascimento = estadoDeNascimento
