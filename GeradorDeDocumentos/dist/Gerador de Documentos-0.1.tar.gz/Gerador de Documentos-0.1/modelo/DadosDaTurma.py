# -*- coding: UTF-8 -*-
"""
andersonferreira1277@gmail.com
"""

class DadosDaTurma:
    def __init__(self, serie, segmento, anoLetivo):
        """Serie, segmento"""
        self.serie = serie
        self.segmento = segmento
        self.anoLetivo = anoLetivo
